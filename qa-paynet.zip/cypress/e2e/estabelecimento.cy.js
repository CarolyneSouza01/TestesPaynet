describe('Cadastro de Estabelecimento', () => {
  beforeEach(() => {
    cy.visit('https://homologslg-pd.paynet.net.br/');
    cy.get('input[name="telefone"]').type('(62)36445-187');
    cy.get('input[name="senha"]').type('380152');
    cy.get('button[type="submit"]').click(); // Ajustar se o botão for diferente
  });

  it('Valida máscaras e bloqueios no formulário', () => {
    cy.contains('Estabelecimentos').click();
    cy.contains('Aguardando Aprovação').click();
    cy.contains('Em Processamento').click();
    cy.contains('Ações').click();
    cy.contains('Criar').click();

    cy.get('input[name="cnpj"]').type('12345678000195')
      .should('have.value', '12.345.678/0001-95');

    cy.get('input[name="nome"]').type('123')
      .should('have.value', '');

    cy.get('input[name="cpf"]').type('123');
    cy.get('button[type="submit"]').click();
    cy.contains('CPF inválido').should('be.visible');
  });
});
