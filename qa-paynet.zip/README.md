# 🧪 QA Paynet – Testes Manuais e Automatizados

Este repositório contém os testes manuais e automatizados (Cypress) para a task técnica da vaga de Analista de QA na Paynet.

## 🔍 Escopo

- Cadastro de Estabelecimento
- Listagem de Estabelecimentos
- Relatórios de Transações

## 📁 Conteúdo

- `docs/`: Checklist dos testes manuais executados
- `cypress/`: Testes automatizados com Cypress

## 🚀 Como rodar os testes automatizados

1. Instale as dependências:

```bash
npm install
```

2. Execute os testes em modo interativo:

```bash
npx cypress open
```

Ou em modo headless:

```bash
npx cypress run
```

---

Credenciais de acesso de homologação fornecidas pela Paynet:

- URL: https://homologslg-pd.paynet.net.br/
- Usuário: (62)36445-187
- Senha: 380152
